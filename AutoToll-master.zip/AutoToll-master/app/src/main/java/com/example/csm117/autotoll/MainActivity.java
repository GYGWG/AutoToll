package com.example.csm117.autotoll;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.util.Base64;
import android.util.Log;
import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.venmo_webview);


        Intent i = new Intent();
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);//重点是加这个
        //ComponentName cn = new ComponentName("com.venmo",
                //"com.venmo.controller.ComposeActivity");
        i.setComponent(new ComponentName("com.tencent.mm", "com.tencent.mm.ui.LauncherUI"));


// Verify it resolves
        PackageManager packageManager = getPackageManager();
        List<ResolveInfo> activities = packageManager.queryIntentActivities(i, 0);
        boolean isIntentSafe = activities.size() > 0;

// Start an activity if it's safe
        if (!isIntentSafe) {

            Uri webpage = Uri.parse("https://play.google.com/store/apps/details?id=com.tencent.mm&hl=en");
            Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
            startActivity(webIntent);
        }
        else {
            startActivityForResult(i, RESULT_OK);
        }

     }






    public static boolean isWechatInstalled(Context context) {
        PackageManager packageManager = context.getPackageManager();
        List<ResolveInfo> activities = packageManager.queryIntentActivities(new Intent()
                .setComponent(new ComponentName("com.tencent.mm", "com.tencent.mm.ui.LauncherUI")), 0);

        return activities.size() == 1 &&
                "com.venmo".equals(activities.get(0).activityInfo.packageName);
    }

}